# Plethora of PIES

Plethora of PIES is a React and Supabase school-project demonstration for a
pickup-only pizza restaurant. Customers can browse the menu, customize pizzas,
manage a cart, apply active promotion codes, and place simulated orders as a
guest or signed-in customer.

No real payment is processed. Full card numbers and security codes remain only
in the checkout page long enough to perform local demonstration validation.
They are never sent to Supabase or stored. Signed-in customers may save only
the cardholder name, card brand, last four digits, and expiration date.

## Initial setup

1. Install the Node.js Long-Term Support release.
2. Run the complete `Database/schema.sql` script in the Supabase SQL Editor.
3. Copy `.env.example` to `.env.local`.
4. Replace the placeholders with the Supabase Project URL and Publishable key.
5. Install dependencies and start Vite:

```powershell
npm.cmd install
npm.cmd run dev
```

Never place a Supabase `service_role` key in this client application. The
publishable key is the only Supabase key used by Vite.

## Main application areas

- **Home:** Loads active specials from Supabase and displays the photo gallery.
- **Menu:** Loads menu content from `src/data/menu.json` and availability
  overrides from Supabase.
- **Cart:** Calculates totals and validates database-backed promotion codes.
- **Checkout:** Supports guest and account checkout for pickup orders.
- **My Account:** Stores profile details, displays account order history, and
  removes saved card metadata.
- **Admin Orders:** Reviews orders and updates their status.
- **Admin Menu:** Enables or disables menu items.
- **Admin Specials:** Creates, activates, deactivates, and removes promotions.

Admin pages are protected in both React and Supabase row-level security. New
registrations always receive the customer role. Administrator roles must be
assigned through a trusted database-management process.

## Project structure

| Location              | Purpose                                           |
| --------------------- | ------------------------------------------------- |
| `src/pages`           | Complete routed screens.                          |
| `src/components`      | Reusable interface components.                    |
| `src/context`         | Shared authentication and cart state.             |
| `src/services`        | Supabase and menu data access.                    |
| `src/data`            | Static restaurant, menu, and gallery content.     |
| `src/utils`           | Pure validation and pricing functions.            |
| `src/test`            | Automated tests for pure validation logic.        |
| `public`              | Images and other static browser assets.           |
| `Database/schema.sql` | Complete idempotent Supabase schema and policies. |

## Verification

Run these commands before opening a pull request:

```powershell
npm.cmd run lint
npm.cmd run test
npm.cmd run build
```

- `lint` checks JavaScript and React rules.
- `test` runs the Node.js automated test suite.
- `build` creates the deployable Vite output in `dist`.

The portable Windows demonstration can be produced with:

```powershell
npm.cmd run electron:build
```

The generated executable is placed in `release` and is intentionally excluded
from Git source control.
